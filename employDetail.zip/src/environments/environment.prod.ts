export const environment = {
  production: true,
  api:'	http://dummy.restapiexample.com/api/v1/',
};
